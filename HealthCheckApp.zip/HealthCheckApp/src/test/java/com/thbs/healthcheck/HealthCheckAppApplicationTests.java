package com.thbs.healthcheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCheckAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
